local scr_pp, scr_name = ...
local scr_fp = (scr_pp ~= "" and scr_pp .. "." or "") .. scr_name

print(scr_fp)

-- local autoloader = require("autoloader")
autoloader.newHook("hooktest_hook", function (...)
    print("Hook Test ===")
    for _, v in ipairs(table.pack(...)) do
        print(v)
    end
end)