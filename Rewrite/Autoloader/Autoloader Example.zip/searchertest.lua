local scr_pp, scr_name = ...
local scr_fp = (scr_pp ~= "" and scr_pp .. "." or "") .. scr_name

print(scr_fp)

autoloader.newSearcher("foo", function (...)
    print("Searcher Test ===")
    for _, v in ipairs(table.pack(...)) do
        print(v)
    end
end)